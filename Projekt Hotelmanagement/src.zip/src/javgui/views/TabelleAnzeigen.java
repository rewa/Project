package javgui.views;

import java.awt.EventQueue;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.GregorianCalendar;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JTable;
import resources.*;

public class TabelleAnzeigen extends JInternalFrame {
	JTable table;

	/**
	 * Launch the application.
	 */
	public TabelleAnzeigen() {
		setResizable(true);
		//setMaximum(true);
		//setIcon(true);
		setIconifiable(true);
		setMaximizable(true);
		setClosable(true);
		getContentPane().setLayout(null);
		setBounds(0, 0, 720, 500);

		
		JButton btnOk = new JButton("OK");
		btnOk.setHorizontalAlignment(SwingConstants.LEFT);
		btnOk.setIcon(new ImageIcon(Gastanlegen.class.getResource("/java/guiresources/Valid.png")));
		btnOk.setBounds(23, 343, 138, 39);
		getContentPane().add(btnOk);
		
		JButton btnAbbrechen = new JButton("Abbrechen");
		btnAbbrechen.setIcon(new ImageIcon(Gastanlegen.class.getResource("/java/guiresources/Error.png")));
		btnAbbrechen.setHorizontalAlignment(SwingConstants.LEFT);
		btnAbbrechen.setBounds(158, 343, 138, 39);
		getContentPane().add(btnAbbrechen);
		
		
		
		String[] columnNames = {"First Name",
                "Last Name",
                "Sport",
                "# of Years",
                "Vegetarian"};
		
		Object[][] data = {
			    {"Kathy", "Smith",
			     "Snowboarding", new Integer(5), new Boolean(false)},
			    {"John", "Doe",
			     "Rowing", new Integer(3), new Boolean(true)},
			    {"Sue", "Black",
			     "Knitting", new Integer(2), new Boolean(false)},
			    {"Jane", "White",
			     "Speed reading", new Integer(20), new Boolean(true)},
			    {"Joe", "Brown",
			     "Pool", new Integer(10), new Boolean(false)}
			};
		//table=new JTable(data,columnNames);
		table.add(Gast.initTable());
		table.setBounds(47, 43, 508, 288);
		
		//getContentPane().add(Gast.initTable());
		getContentPane().add(table);
	

	}
}

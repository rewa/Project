package resources;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;
import javax.swing.JTable;

public class Mitarbeiter {
//TODO anpassen mit Datenbank inkl allen MEthoden
	
	private int mitarbeiterId = -1;
	private String vorName = null;
	private String nachName = null;
	private String ort = null;
      private String teleNR = null;
      private String DOB = null;
      private String strasse = null;
      private int plz=0;
      private String email = null;
      private double gehalt = 0;
      private String taetigkeit = null;
      private Boolean geschlecht = true; 
      //true = weiblich
      
      
      
	public Mitarbeiter(String vorName, String nachName, String ort,String teleNR,
			String dOB, String strasse, int plz, String email, double gehalt,
			String taetigkeit, Boolean geschlecht) {
		super();
		this.vorName = vorName;
		this.nachName = nachName;
		this.ort = ort;
		this.teleNR = teleNR;
		DOB = dOB;
		this.strasse = strasse;
		this.plz = plz;
		this.email = email;
		this.gehalt = gehalt;
		this.taetigkeit = taetigkeit;
		this.geschlecht = geschlecht;
	}

	public Boolean getGeschlecht() {
		return geschlecht;
	}

	public void setGeschlecht(Boolean geschlecht) {
		this.geschlecht = geschlecht;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public String getStrasse() {
		return strasse;
	}

	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	public int getPlz() {
		return plz;
	}

	public void setPlz(int plz) {
		this.plz = plz;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getGehalt() {
		return gehalt;
	}

	public void setGehalt(double gehalt) {
		this.gehalt = gehalt;
	}

	public String getTaetigkeit() {
		return taetigkeit;
	}

	public void setTaetigkeit(String taetigkeit) {
		this.taetigkeit = taetigkeit;
	}
	
	public int getMitarbeiterId() {
		return mitarbeiterId;
	}
	public void setMitarbeiterId(int mitarbeiterId) {
		this.mitarbeiterId = mitarbeiterId;
	}
	public String getVorName() {
		return vorName;
	}
	public void setVorName(String vorName) {
		this.vorName = vorName;
	}
	public String getNachName() {
		return nachName;
	}
	public void setNachName(String nachName) {
		this.nachName = nachName;
	}
	public String getOrt() {
		return ort;
	}
	public void setOrt(String ort) {
		this.ort = ort;
	}
	public String getTeleNR() {
		return teleNR;
	}
	public void setTeleNR(String teleNR) {
		this.teleNR = teleNR;
	}
      
      public void MAanlegen(String vorName, String nachName, String ort,String teleNR,
			String dOB, String strasse, int plz, String email, double gehalt,
			String taetigkeit, Boolean geschlecht){
    	  //getText von Gui
    	  Mitarbeiter newM = new Mitarbeiter(vorName, nachName,ort, teleNR, dOB, strasse, plz, email,gehalt, taetigkeit, geschlecht );
    	  
    
  		Connection c = ConnectionFactory.createConnection();
  		
  		try {
  			PreparedStatement s = c.prepareStatement("INSERT INTO mitarbeiter (vorName, nachName, ort,teleNR," +
  					"	dOB, strasse, plz, email,gehalt, taetigkeit, geschlecht) "
  					+ " values (?, ?, ?, ?,?, ?, ?, ?,?, ?, ? );"
  					, Statement.RETURN_GENERATED_KEYS);
  			s.setString(1, this.getVorName());
  			s.setString(2, this.getNachName());
  			s.setString(3, this.getOrt());
  			s.setString(4, this.getTeleNR());
  			s.setString(5, this.getDOB());
  			s.setString(6, this.getStrasse());
  			s.setInt(7, this.getPlz());
  			s.setString(8, this.getEmail());
  			s.setDouble(9, this.getGehalt());
  			s.setString(10, this.getTaetigkeit());
  			s.setBoolean(11, this.getGeschlecht());
  			
  			s.execute();
  			ResultSet erg = s.getGeneratedKeys();
  			if(erg.next()) {
  				this.setMitarbeiterId(erg.getInt(1));
  			}
  			c.commit();
  			
  		} catch (SQLException e){
  			e.printStackTrace();
  		} finally {
  			try {
  				c.close();
  			} catch (SQLException e) {
  				e.printStackTrace();
  			}
  		}
    	  
      }
      
      
}
package resources;

import javgui.views.MainGui;

public class Hotel {
	
	
	public static void main (String args []){
		
		MainGui.guishow();
		
		
	}

}

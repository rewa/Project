package resources;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;
import javax.swing.JTable;

public class Gast {

	private int idGast = -1;
	private String vorName = null;
	private String nachName = null;
	private String strasse = null;

	private int teleNR;
	private String mobilTel = null;
	private String email = null;
	private String DOB = null;
	private String geschlecht;
	private String ausweisnr = null;
	private String staatsangehoerigkeit = null;
	private int GAdresse_ID = -1;

	private int idGAdresse = -1;
	private int plz = -1;
	private String ort = null;
	private String land = null;

	private int bankknt = -1;
	private String kreditinstitut = null;
	private int kontonr = -1;
	private int blz = -1;
	private String iban = null;

	// mit ID
	public Gast(int idGast, String vorName, String nachName, String strasse,
			int teleNR, String mobilTel, String email, String dOB,
			String geschlecht, String ausweisnr, String staatsangehoerigkeit,
			int gAdresse_ID, int idGAdresse, int plz, String ort, String land,
			int bankknt, String kreditinstitut, int kontonr, int blz,
			String iban) {
		super();
		this.idGast = idGast;
		this.vorName = vorName;
		this.nachName = nachName;
		this.strasse = strasse;
		this.teleNR = teleNR;
		this.mobilTel = mobilTel;
		this.email = email;
		DOB = dOB;
		this.geschlecht = geschlecht;
		this.ausweisnr = ausweisnr;
		this.staatsangehoerigkeit = staatsangehoerigkeit;
		GAdresse_ID = gAdresse_ID;
		this.idGAdresse = idGAdresse;
		this.plz = plz;
		this.ort = ort;
		this.land = land;
		this.bankknt = bankknt;
		this.kreditinstitut = kreditinstitut;
		this.kontonr = kontonr;
		this.blz = blz;
		this.iban = iban;
	}

	// TODO ID Gast automatisch hinzuf�gen
	// ohne IDGast
	public Gast(String vorName, String nachName, String strasse, int teleNR,
			String mobilTel, String email, String dOB, String geschlecht,
			String ausweisnr, String staatsangehoerigkeit, int gAdresse_ID,
			int idGAdresse, int plz, String ort, String land, int bankknt,
			String kreditinstitut, int kontonr, int blz, String iban) {
		super();
		this.vorName = vorName;
		this.nachName = nachName;
		this.strasse = strasse;
		this.teleNR = teleNR;
		this.mobilTel = mobilTel;
		this.email = email;
		DOB = dOB;
		this.geschlecht = geschlecht;
		this.ausweisnr = ausweisnr;
		this.staatsangehoerigkeit = staatsangehoerigkeit;
		GAdresse_ID = gAdresse_ID;
		this.idGAdresse = idGAdresse;
		this.plz = plz;
		this.ort = ort;
		this.land = land;
		this.bankknt = bankknt;
		this.kreditinstitut = kreditinstitut;
		this.kontonr = kontonr;
		this.blz = blz;
		this.iban = iban;
	}

	public int getIdGast() {
		return idGast;
	}

	public void setIdGast(int idGast) {
		this.idGast = idGast;
	}

	public String getVorName() {
		return vorName;
	}

	public void setVorName(String vorName) {
		this.vorName = vorName;
	}

	public String getNachName() {
		return nachName;
	}

	public void setNachName(String nachName) {
		this.nachName = nachName;
	}

	public String getStrasse() {
		return strasse;
	}

	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	public int getTeleNR() {
		return teleNR;
	}

	public void setTeleNR(int teleNR) {
		this.teleNR = teleNR;
	}

	public String getMobilTel() {
		return mobilTel;
	}

	public void setMobilTel(String mobilTel) {
		this.mobilTel = mobilTel;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public String getGeschlecht() {
		return geschlecht;
	}

	public void setGeschlecht(String geschlecht) {
		this.geschlecht = geschlecht;
	}

	public String getAusweisnr() {
		return ausweisnr;
	}

	public void setAusweisnr(String ausweisnr) {
		this.ausweisnr = ausweisnr;
	}

	public String getStaatsangehoerigkeit() {
		return staatsangehoerigkeit;
	}

	public void setStaatsangehoerigkeit(String staatsangehoerigkeit) {
		this.staatsangehoerigkeit = staatsangehoerigkeit;
	}

	public int getGAdresse_ID() {
		return GAdresse_ID;
	}

	public void setGAdresse_ID(int gAdresse_ID) {
		GAdresse_ID = gAdresse_ID;
	}

	public int getIdGAdresse() {
		return idGAdresse;
	}

	public void setIdGAdresse(int idGAdresse) {
		this.idGAdresse = idGAdresse;
	}

	public int getPlz() {
		return plz;
	}

	public void setPlz(int plz) {
		this.plz = plz;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getLand() {
		return land;
	}

	public void setLand(String land) {
		this.land = land;
	}

	public int getBankknt() {
		return bankknt;
	}

	public void setBankknt(int bankknt) {
		this.bankknt = bankknt;
	}

	public String getKreditinstitut() {
		return kreditinstitut;
	}

	public void setKreditinstitut(String kreditinstitut) {
		this.kreditinstitut = kreditinstitut;
	}

	public int getKontonr() {
		return kontonr;
	}

	public void setKontonr(int kontonr) {
		this.kontonr = kontonr;
	}

	public int getBlz() {
		return blz;
	}

	public void setBlz(int blz) {
		this.blz = blz;
	}

	public String getIban() {
		return iban;
	}

	public void setIban(String iban) {
		this.iban = iban;
	}

	// geschlecht char, ausweisnr string, warum telenr als int und mobil als
	// varchar?
	// procedure

	public void GastanlegenProcedure() {
		Connection c = ConnectionFactory.createConnection();

		try {
			PreparedStatement s = c
					.prepareStatement("call gastanlegen (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);");
			s.setInt(1, this.idGast);
			s.setString(2, this.vorName);
			s.setString(3, this.nachName);
			s.setString(4, this.strasse);
			s.setInt(5, this.teleNR);
			s.setString(6, this.mobilTel);
			s.setString(7, this.email);
			s.setString(8, this.DOB);
			s.setString(9, this.geschlecht);
			s.setString(10, this.ausweisnr);
			s.setString(11, this.staatsangehoerigkeit);
			s.setInt(12, this.GAdresse_ID);
			s.setInt(13, this.idGAdresse);
			s.setInt(14, this.plz);
			s.setString(15, this.ort);
			s.setString(16, this.land);
			s.setInt(17, this.bankknt);
			s.setString(18, this.kreditinstitut);
			s.setInt(19, this.kontonr);
			s.setInt(20, this.blz);
			s.setString(21, this.iban);

			s.execute();
			c.commit();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				c.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/*
	 * public static void GastanlegenProcedure(int idGast, String vorName,
	 * String nachName, String strasse, int teleNR, String mobilTel, String
	 * email, String dOB, String geschlecht, String ausweisnr, String
	 * staatsangehoerigkeit, int gAdresse_ID, int idGAdresse, int plz, String
	 * ort, String land, int bankknt, String kreditinstitut, int kontonr, int
	 * blz, String iban) {
	 * 
	 * 
	 * Connection c = ConnectionFactory.createConnection();
	 * 
	 * try {
	 * 
	 * /* Statement s = c.createStatement(); s.executeUpdate(
	 * "call gastanlegen (idGast, vorName, nachName, strasse, teleNR, mobilTel,  email, dOB, geschlecht,ausweisnr,  staatsangehoerigkeit, gAdresse_ID, idGAdresse, plz,  ort,  land, bankknt, kreditinstitut,  kontonr,  blz,iban );"
	 * ); c.commit();
	 */

	// PreparedStatement s = ("call gastenlegen (
	// c.prepareStatement("call gastanlegen (idGast, 'vorName', 'nachName', 'strasse', teleNR, 'mobilTel',  'email', 'dOB', 'geschlecht','ausweisnr',  'staatsangehoerigkeit', gAdresse_ID, idGAdresse, plz,  'ort',  'land', bankknt, 'kreditinstitut',  kontonr,  blz,'iban' ); "

	/*
	 * PreparedStatement s = c.prepareStatement(
	 * "call gastanlegen (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);");
	 * s.setInt(1, idGast); s.setString(2, vorName); s.setString(3, nachName);
	 * s.setString(4, strasse); s.setInt(5, teleNR); s.setString(6, mobilTel);
	 * s.setString(7, email); s.setString(8, dOB); s.setString(9, geschlecht);
	 * s.setString(10, ausweisnr); s.setString(11, staatsangehoerigkeit);
	 * s.setInt(12, gAdresse_ID); s.setInt(13, idGAdresse); s.setInt(14, plz);
	 * s.setString(15, ort); s.setString(16, land); s.setInt(17, bankknt);
	 * s.setString(18, kreditinstitut); s.setInt(19, kontonr); s.setInt(20,
	 * blz); s.setString(21, iban);
	 * 
	 * s.execute(); c.commit();
	 * 
	 * } catch (SQLException e) { e.printStackTrace(); } finally { try {
	 * c.close(); } catch (SQLException e) { e.printStackTrace(); } }
	 * 
	 * }
	 */

	public static JTable initTable(){
		
		JTable table = null;
		String query = "select * from mitarbeiter";
		Connection c = ConnectionFactory.createConnection();

		try {
				
			//statement creation
						
			Statement state = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			
			// Query execution

			ResultSet res = state.executeQuery(query);

					
			// retrieve of the meta data in order to retrieve the columns names 
			ResultSetMetaData meta = res.getMetaData();

			// Initialization of an array for the titles of the array columns
			Object[] column = new Object[meta.getColumnCount()];
			
			for(int i = 1 ; i <= meta.getColumnCount(); i++){
				column[i-1] = meta.getColumnName(i);
			}
			
			// retrieving the number of lines (Results)
			res.last();

			Object[][] data = new Object[res.getRow()][meta.getColumnCount()];
			
			// getting the cursor to the first line :)
			res.beforeFirst();
			int j = 1;
			
			// we fill the array with objects (Object[][])
			while(res.next()){
				for(int i = 1 ; i <= meta.getColumnCount(); i++)
					data[j-1][i-1] = res.getObject(i);
				j++;
			}
			                      
			res.close();
			state.close();
			
			// execution time calculation

			
			/**TODO
			 * 
			 */
			//result.removeAll();
			

				table = new JTable(data, column){              
					
					/**
					 * 
					 */
					private static final long serialVersionUID = 1L;

					public boolean isCellEditable(final int row, final int column) { 
						return false;
	               }
	          };
	          

	          for(int i=0; i<20 ;i++)
	          {
	        	  table.getColumnModel().getColumn(i);
	          }
			

		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "ERROR ! ", JOptionPane.ERROR_MESSAGE);
		}
		return table;
	}
  
}


